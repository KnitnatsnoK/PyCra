from glm import dot, vec2, normalize

def pointing_amount(vector:vec2, origin:vec2, target:vec2):
    # Create the vector from the origin to the target
    target_vector = target - origin

    # Calculate the dot product between the two normalized vectors
    alignment = dot(normalize(vector), normalize(target_vector))
    return alignment

# Example usage
origin = vec2(0, 0)      # The vector origin (position)
vector = vec2(1.75, -3)  # The vector
target = vec2(3, 0)      # The target point

alignment = pointing_amount(vector, origin, target)
print(f"The vector points {alignment:.2f} towards the target.")
