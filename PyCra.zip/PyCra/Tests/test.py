from pyjoycon import GyroTrackingJoyCon, get_device_ids
import time

def list_joycon_devices():
    joycon_ids = get_device_ids()
    if not joycon_ids:
        print("No Joy-Con devices found")
    else:
        for joycon_id in joycon_ids:
            print(f"Vendor ID: {joycon_id[0]:#06x}, Product ID: {joycon_id[1]:#06x}")
    return joycon_ids

joycon_IDs = list_joycon_devices()
joycons = [GyroTrackingJoyCon(*joycon_id) for joycon_id in joycon_IDs]

for _ in range(2):
    for joycon in joycons:
        print(joycon)
        print("joycon rotation:", joycon.rotation)
        print("joycon direction:", joycon.direction)
    print()
    time.sleep(1/1)