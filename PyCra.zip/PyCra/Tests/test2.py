import pygame as pg
from sys import exit as sys_exit
from glm import vec2

SCREEN_SIZE = vec2(720, 480)
WIDTH, HEIGHT = SCREEN_SIZE
screen = pg.display.set_mode(SCREEN_SIZE)

class Panel:
    def __init__(self, pos: vec2, size: vec2):
        self.pos = pos
        self.size = size

# Initialize two panels, splitting the screen horizontally
panels = [
    Panel(vec2(0, 0), vec2(WIDTH/2, HEIGHT)),
    Panel(vec2(WIDTH/2, 0), vec2(WIDTH/2, HEIGHT))
]

# Set up groups for panels by edge positions
panel_groups: dict[int, list[int]] = {}

def initialize_panel_groups():
    panel_groups.clear()
    for i, panel in enumerate(panels):
        for edge in [panel.pos.x, panel.pos.x + panel.size.x]:
            edge = int(edge)
            if edge in [0, WIDTH]:  # Skip edges of the window
                continue
            if edge not in panel_groups:
                panel_groups[edge] = [i]
            else:
                panel_groups[edge].append(i)

initialize_panel_groups()

moving_panel = None
min_panel_width = 20

def tick():
    global moving_panel

    if not pg.mouse.get_pressed()[0]:  # Reset dragging when the mouse is not pressed
        moving_panel = None
        initialize_panel_groups()  # Reinitialize panel groups to reflect new positions
        return

    mpos = vec2(pg.mouse.get_pos())

    if moving_panel is not None:
        # Moving and resizing panels while ensuring minimum size constraints
        offset = int(mpos.x) - moving_panel
        left_panel = panels[panel_groups[moving_panel][0]]
        right_panel = panels[panel_groups[moving_panel][1]]

        offset = int(mpos.x) - moving_panel
    
        # Limit the offset for the left panel based on minimum width
        if left_panel.size.x + offset < min_panel_width:
            # Adjust to the max allowed offset for left panel
            offset = min_panel_width - left_panel.size.x

        # Limit the offset for the right panel based on minimum width
        elif right_panel.size.x - offset < min_panel_width:
            # Adjust to the max allowed offset for right panel
            offset = right_panel.size.x - min_panel_width

        # Check minimum width constraints for both panels
        if True: #left_panel.size.x + offset >= min_panel_width and right_panel.size.x - offset >= min_panel_width
            left_panel.size.x += offset
            right_panel.pos.x += offset
            right_panel.size.x -= offset

            # Update moving position
            panel_groups[int(mpos.x)] = panel_groups.pop(moving_panel)
            moving_panel = int(mpos.x)

        return

    # Check if mouse is near an edge and initiate dragging
    for edge in list(panel_groups.keys()):
        if abs(mpos.x - edge) < 4:
            moving_panel = edge
            break

def draw():
    for panel in panels:
        pg.draw.rect(screen, (50, 50, 50), (*panel.pos, *(panel.size - 2)))

# Game loop
clock = pg.time.Clock()
while True:
    clock.tick(60)
    for event in pg.event.get():
        if event.type == pg.QUIT:
            pg.quit()
            sys_exit()
        elif event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE:
            pg.quit()
            sys_exit()

    screen.fill((0, 0, 0))
    tick()
    draw()
    pg.display.flip()