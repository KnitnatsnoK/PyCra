# You can import necessary modules or functions from .py files in the "Scripts" folder
from objects import pg, KEYS, MOUSE, change_to_scene, create_Dynamic_Texture_Object, create_Background_Object, GameObject, DynamicObject, vec2, length, ALL_WINDOW_MANAGERS
from UI import create_Text_Box
from imports import bind_function_to_class, change_main_window_name, CAMERA
from global_variables import get_global, set_global
from global_values import *

change_to_scene("test_scene")
change_main_window_name("Super Duper Game")

ALL_WINDOW_MANAGERS[0].set_window_size(RES_HD)

create_Text_Box(ALL_WINDOW_MANAGERS[0], vec2(0), text="Cool Button", font_size=24, action=4)

background = create_Background_Object("test_scene", 0, ALL_WINDOW_MANAGERS[0].window_size/2, 1.5*vec2(960, 540), depth=3, image_path="background.jpg", center=True)

player = create_Dynamic_Texture_Object("test_scene", 0, vec2(480, 270), size=2, mass=1, image_path="bird1.png", center=True)
CAMERA.bind_object(player)

player.jumping = 0
player.falling = 0
def custom_inputs(self:DynamicObject, fps_factor):
	speed = 5
	if not MOUSE.pressed_buttons[2]:
		self.vel.x = 0
	if KEYS.check_pressed(pg.K_a):
		self.vel.x = -speed
	elif KEYS.check_pressed(pg.K_d):
		self.vel.x = speed
	if KEYS.check_pressed(pg.K_w):
		if self.jumping < 20 and self.falling < 10:
			self.vel.y = -13
			self.jumping += 1*fps_factor
	else:
		if self.ground:
			self.jumping = 0
			self.falling = 0
	if self.vel.y != 0:
		self.falling += 1*fps_factor

bind_function_to_class("inputs", custom_inputs, player)

# This function runs every frame, so don't do any 'while True - loops' if possible
def tick():
	if MOUSE.pressed_buttons[2]:
		vel = (MOUSE.scene_position-player.size/2 - player.pos) / max(1, player.mass / 1000)
		player.vel = normalize(vel) * min(20, length(vel))
	if KEYS.check_down(pg.K_p):
		print(player.pos - player.parameters[3])
	if KEYS.check_down(pg.K_F11):
		ALL_WINDOW_MANAGERS[0].toggle_fullscreen()
